const emojiArray = [
  { emoji: "💯", name: "100" },
  { emoji: "🔢", name: "1234" },
  { emoji: "😀", name: "Sırıtma" },
  { emoji: "😬", name: "Ekşitme" },
  { emoji: "😁", name: "Sırıtış" },
  { emoji: "😂", name: "Neşeli" },
  { emoji: "😀", name: "Gülen Yüz" },
  { emoji: "😄", name: "Gülümsemek" },
  { emoji: "😅", name: "Tatlı Gülüş" },
  { emoji: "😆", name: "Kahkaha Atma" },
  { emoji: "😇", name: "Sevimli Melek" },
  { emoji: "😉", name: "Göz Kırpma" },
  { emoji: "😊", name: "Utanma" },
  { emoji: "🙂", name: "Hafif Gülümseme" },
  { emoji: "🙃", name: "Baş Aşağı Gülümseme" },
  { emoji: "😊", name: "Relax Gülümseme" },
  { emoji: "😋", name: "Yum Yum Gülümseme" },
  { emoji: "😌", name: "Huzurlu Gülümseme" },
  { emoji: "😍", name: "Sevgi Dolu Gülümseme" },
  { emoji: "😘", name: "Öpücük" },

];
export default emojiArray;
